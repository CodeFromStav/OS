#include <stdio.h>
#include <sys/time.h>
#include "log.h"
#include "MetaDataAccess.h"
#include "ConfigAccess.h"


LogSettings* currentSettings;


void logToFile(char * message )
{
	FILE *logFile;
	logFile = fopen( currentSettings->logFile, "w" );
	fprintf(logFile, " %s\n", message );
	fclose(logFile);
}

void startLogging(LogSettings* settings)
{
	if( currentSettings == NULL )
		{
			settings->logAmount = 0;
			currentSettings = settings;
		}
}

void logLine( char* message)
{
	if(currentSettings->printToLog == true)
	{
		logToFile(message);		
	}
	if(currentSettings->printToMonitor == true)
		{
			printf("%d: %s\n", message );
		}
}

void stopLogging()
{
	currentSettings = NULL;
}
